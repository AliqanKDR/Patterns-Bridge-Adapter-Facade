package com.company;

public class PcApplication {
    public void openApp(){
        System.out.println("opening application");
    };
    public void loadApp(){
        System.out.println("loading application");
    };
    public void playApp(){
        System.out.println("play application");
    };
    public void closeApp(){
        System.out.println("close application");
    };
}
