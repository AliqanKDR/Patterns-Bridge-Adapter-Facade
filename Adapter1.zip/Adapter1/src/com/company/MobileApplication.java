package com.company;

public interface MobileApplication {
    public void open();
    public void load();
    public void play();
    public void close();
}
